<?php

namespace App\Http\Controllers;

use App\Models\aset;
use App\Models\detail_pengadaan;
use App\Models\jalan_irigasi_dan_jaringan;
use App\Models\rekening;
use App\Models\tanah;
use Illuminate\Http\Request;

class gjalan_irigasi_dan_jaringanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Fetch all necessary models
        $aset = aset::all();
        $rekening = rekening::all();
        $jalan_irigasi_dan_jaringan = jalan_irigasi_dan_jaringan::paginate(5);

        // Return the view with the fetched data
        return view('page.golongan.jalan_irigasi_dan_jaringan.index', compact('aset', 'rekening', 'jalan_irigasi_dan_jaringan'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(String $id)
    {
        // Return the view for creating a new resource
        $rekening = rekening::where('id_golongan', 'like', '4')->get();
        $aset = aset::all();
        $jalan_irigasi_dan_jaringan = jalan_irigasi_dan_jaringan::all();
        $tanah = tanah::all();
        return view('page.golongan.jalan_irigasi_dan_jaringan.create', compact('rekening', 'aset', 'jalan_irigasi_dan_jaringan', 'tanah', 'id'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $count = Aset::where('id_rekening', $request->input('id_rekening'))->count();
        $register = $count + 1;
        $rekening = Rekening::find($request->input('id_rekening'));

        if (!$rekening) {
            return back()->withErrors(['id_rekening' => 'Rekening tidak ditemukan']);
        }

        $no_rekening = $rekening->kode;
        $now = now();
        $year = $now->format('Y');

        $id_barang = "32.12.9.2008.{$no_rekening}.{$year}";

        $idPengadaan = $request->input('id_pengadaan');
        $dataAset = [
            'id_barang' => $id_barang,
            'nomor_register' => $register,
            'id_rekening' => $request->input('id_rekening'),
            'nama_label' => $request->input('nama_label'),
            'kode_belanja_bidang' => $request->input('kode_belanja_bidang'),
            'asal' => $request->input('asal'),
            'sumber_dana' => $request->input('sumber_dana'),
            'nilai_perolehan' => $request->input('nilai_perolehan'),
            'kondisi' => $request->input('kondisi'),
            'tanggal_pembukuan' => $request->input('tanggal_pembukuan'),
            'tanggal_perolehan' => $request->input('tanggal_perolehan'),
            'keterangan' => $request->input('keterangan'),
        ];
        aset::create($dataAset);
        $id_aset = aset::latest()->first()->id;

        $dataJalanIrigasiDanJaringan = [
            'id_aset' => $id_aset,
            'kode_pemilik' => $request->input('kode_pemilik'),
            'kontruksi' => $request->input('kontruksi'),
            'panjang' => $request->input('panjang'),
            'lebar' => $request->input('lebar'),
            'luas' => $request->input('luas'),
            'no_dokumen' => $request->input('no_dokumen'),
            'tanggal_dokumen' => $request->input('tanggal_dokumen'),
            'id_tanah' => $request->input('id_tanah'),
            'perolehan' => $request->input('perolehan'),
            'lokasi' => $request->input('lokasi'),
        ];
        jalan_irigasi_dan_jaringan::create($dataJalanIrigasiDanJaringan);

        if ($idPengadaan != 0) {
            $details = [
                'id_pengadaan' => $idPengadaan,
                'id_aset' => $id_aset,
            ];
            detail_pengadaan::create($details);
            return redirect()->route('pengadaan.show', $idPengadaan)->with('message', 'Data Jalan, Irigasi dan Jaringan Berhasil Ditambahkan');
        } else {
            return redirect()->route('jalan_irigasi_dan_jaringan.index')->with('message', 'Data Jalan, Irigasi dan Jaringan Berhasil Ditambahkan');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id, string $id_pengadaan)
    {
        // Fetch the specific resource by ID
        $jalan_irigasi_dan_jaringan = jalan_irigasi_dan_jaringan::findOrFail($id);
        $aset = aset::all();
        $rekening = rekening::where('id_golongan', 'like', '4')->get();
        $tanah = tanah::all();

        // Return the view for editing the resource
        return view('page.golongan.jalan_irigasi_dan_jaringan.edit', compact('jalan_irigasi_dan_jaringan', 'aset', 'rekening', 'tanah', 'id_pengadaan'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $count = Aset::where('id_rekening', $request->input('id_rekening'))->count();
        $register = $count + 1;
        $rekening = Rekening::find($request->input('id_rekening'));

        if (!$rekening) {
            return back()->withErrors(['id_rekening' => 'Rekening tidak ditemukan']);
        }

        $no_rekening = $rekening->kode;
        $now = now();
        $year = $now->format('Y');

        $id_barang = "32.12.9.2008.{$no_rekening}.{$year}";

        $idPengadaan = $request->input('id_pengadaan');
        $jalan_irigasi_dan_jaringan = jalan_irigasi_dan_jaringan::findOrFail($id);
        $aset = aset::findOrFail($jalan_irigasi_dan_jaringan->id_aset);

        $dataAset = [
            'id_barang' => $id_barang,
            'nomor_register' => $register,
            'id_rekening' => $request->input('id_rekening'),
            'nama_label' => $request->input('nama_label'),
            'kode_belanja_bidang' => $request->input('kode_belanja_bidang'),
            'asal' => $request->input('asal'),
            'sumber_dana' => $request->input('sumber_dana'),
            'nilai_perolehan' => $request->input('nilai_perolehan'),
            'kondisi' => $request->input('kondisi'),
            'tanggal_pembukuan' => $request->input('tanggal_pembukuan'),
            'tanggal_perolehan' => $request->input('tanggal_perolehan'),
            'keterangan' => $request->input('keterangan'),
        ];
        $aset->update($dataAset);

        $dataJalanIrigasiDanJaringan = [
            'kode_pemilik' => $request->input('kode_pemilik'),
            'kontruksi' => $request->input('kontruksi'),
            'panjang' => $request->input('panjang'),
            'lebar' => $request->input('lebar'),
            'luas' => $request->input('luas'),
            'no_dokumen' => $request->input('no_dokumen'),
            'tanggal_dokumen' => $request->input('tanggal_dokumen'),
            'id_tanah' => $request->input('id_tanah'),
            'perolehan' => $request->input('perolehan'),
            'lokasi' => $request->input('lokasi'),
        ];
        $jalan_irigasi_dan_jaringan->update($dataJalanIrigasiDanJaringan);

        if ($idPengadaan != 0) {
            return redirect()->route('pengadaan.show', $idPengadaan)
                ->with('message', 'Data Jalan, Irigasi dan Jaringan Berhasil Diperbarui');
        } else {
            return redirect()->route('jalan_irigasi_dan_jaringan.index')
                ->with('message', 'Data Jalan, Irigasi dan Jaringan Berhasil Diperbarui');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $jalan_irigasi_dan_jaringan = jalan_irigasi_dan_jaringan::findOrFail($id);
        $aset = aset::findOrFail($jalan_irigasi_dan_jaringan->id_aset);

        // Delete the jalan_irigasi_dan_jaringan and its associated aset
        $jalan_irigasi_dan_jaringan->delete();
        $aset->delete();

        return redirect()->route('jalan_irigasi_dan_jaringan.index')->with('message', 'Data Jalan, Irigasi dan Jaringan Berhasil Dihapus');
    }
}
